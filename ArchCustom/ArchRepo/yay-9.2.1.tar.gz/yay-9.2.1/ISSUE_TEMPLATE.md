#### Affected Version
<!-- Please ensure you are using the latest yay-git package -->
<!-- Use `yay -V` to get installed version -->
<!-- Example: `yay v8.1139.r0.g9ac4ab6 - libalpm v11.0.1` -->

#### Issue


<!-- The following sections may be left out if not relevant -->
#### Steps to reproduce
<!-- Use exact commands where applicable -->
1.
2.
3.

#### Output
<!-- Include the FULL output -->
<!-- Include any relevant commands/configs -->
<!-- The current yay config can be printed with `yay -Pg` -->
<!-- Use code blocks -->
<!-- Paste services are only needed for excessive output (>500 lines) -->
